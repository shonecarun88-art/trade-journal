
export type Session = 'London' | 'NY' | 'Asia';
export type Result = 'Win' | 'Loss' | 'BE';
export type Emotion = 'Calm' | 'Stressed' | 'Confident' | 'Revenge';

export interface Trade {
  id: string;
  date: string;
  pair: string;
  session: Session;
  setup: string;
  riskAmount: number;
  stopLoss: string;
  takeProfit: string;
  result: Result;
  rrRatio: number;
  pnl: number;
  screenshot?: string;
  emotion: Emotion;
  followedRules: boolean;
  notes: string;
}

export interface JournalState {
  initialBalance: number;
  currentBalance: number;
  trades: Trade[];
  dailyLossLimit: number;
  aiInsights?: string;
}

export enum View {
  Dashboard = 'dashboard',
  Trades = 'trades',
  Analytics = 'analytics',
  Settings = 'settings'
}
