
import { Trade } from '../types';

export const calculateWinRate = (trades: Trade[]) => {
  if (trades.length === 0) return 0;
  const wins = trades.filter(t => t.result === 'Win').length;
  return (wins / trades.length) * 100;
};

export const calculateRuleAdherence = (trades: Trade[]) => {
  if (trades.length === 0) return 0;
  const followed = trades.filter(t => t.followedRules).length;
  return (followed / trades.length) * 100;
};

export const calculateMaxDrawdown = (trades: Trade[], initialBalance: number) => {
  let peak = initialBalance;
  let maxDD = 0;
  let currentBalance = initialBalance;

  trades.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()).forEach(trade => {
    currentBalance += trade.pnl;
    if (currentBalance > peak) peak = currentBalance;
    const dd = ((peak - currentBalance) / peak) * 100;
    if (dd > maxDD) maxDD = dd;
  });

  return maxDD;
};

export const getDailyPnL = (trades: Trade[], dateStr: string) => {
  return trades
    .filter(t => t.date === dateStr)
    .reduce((sum, t) => sum + t.pnl, 0);
};

export const getConsecutiveLosses = (trades: Trade[]) => {
  let max = 0;
  let current = 0;
  const sorted = [...trades].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  
  for (const trade of sorted) {
    if (trade.result === 'Loss') {
      current++;
      if (current > max) max = current;
    } else if (trade.result === 'Win') {
      break; // Only tracking current streak or we could track historical
    }
  }
  return current; 
};
