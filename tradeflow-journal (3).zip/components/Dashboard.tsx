
import React from 'react';
import StatCard from './StatCard';
import { JournalState } from '../types';
import { 
  calculateWinRate, 
  calculateRuleAdherence, 
  calculateMaxDrawdown,
  getDailyPnL,
  getConsecutiveLosses
} from '../utils/calculations';
import { TrendingUp, Percent, AlertCircle, BarChart2, ShieldCheck, DollarSign } from 'lucide-react';

interface DashboardProps {
  state: JournalState;
  onUpdateBalance: (balance: number) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ state, onUpdateBalance }) => {
  const totalPnL = state.trades.reduce((sum, t) => sum + t.pnl, 0);
  const winRate = calculateWinRate(state.trades);
  const ruleAdherence = calculateRuleAdherence(state.trades);
  const maxDD = calculateMaxDrawdown(state.trades, state.initialBalance);
  
  const today = new Date().toISOString().split('T')[0];
  const todayPnL = getDailyPnL(state.trades, today);
  const isDailyLimitExceeded = todayPnL <= -state.dailyLossLimit;
  const streak = getConsecutiveLosses(state.trades);

  const avgRR = state.trades.length > 0 
    ? state.trades.reduce((sum, t) => sum + t.rrRatio, 0) / state.trades.length 
    : 0;

  return (
    <div className="space-y-6">
      {/* Risk Warning */}
      {isDailyLimitExceeded && (
        <div className="bg-rose-900/30 border border-rose-500/50 p-4 rounded-xl flex items-center space-x-4 animate-pulse">
          <AlertCircle className="text-rose-500 w-8 h-8 flex-shrink-0" />
          <div>
            <h3 className="text-rose-500 font-bold uppercase tracking-tight">STOP TRADING TODAY</h3>
            <p className="text-sm text-zinc-300">Daily loss limit of ${state.dailyLossLimit} reached. Protect your capital for tomorrow.</p>
          </div>
        </div>
      )}

      {/* Manual Balance Update */}
      <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-zinc-400 text-sm font-medium uppercase tracking-wider mb-1">Account Balance</h2>
          <div className="text-4xl font-black mono text-emerald-500">${state.currentBalance.toFixed(2)}</div>
        </div>
        <div className="flex items-center space-x-2">
          <input 
            type="number" 
            className="bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 outline-none focus:border-emerald-500 w-32 mono"
            defaultValue={state.currentBalance}
            onBlur={(e) => onUpdateBalance(parseFloat(e.target.value))}
          />
          <span className="text-zinc-500 text-xs">Update Balance</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          label="Total P&L" 
          value={`$${totalPnL.toFixed(2)}`} 
          subValue={totalPnL >= 0 ? 'Profit' : 'Loss'} 
          trend={totalPnL >= 0 ? 'up' : 'down'}
          icon={<TrendingUp size={18}/>}
        />
        <StatCard 
          label="Win Rate" 
          value={`${winRate.toFixed(1)}%`} 
          subValue={`${state.trades.filter(t=>t.result==='Win').length} Wins`}
          trend="neutral"
          icon={<Percent size={18}/>}
        />
        <StatCard 
          label="Avg Risk:Reward" 
          value={`1:${avgRR.toFixed(1)}`} 
          subValue="Theoretical"
          trend="neutral"
          icon={<BarChart2 size={18}/>}
        />
        <StatCard 
          label="Max Drawdown" 
          value={`${maxDD.toFixed(1)}%`} 
          subValue="Historical peak-to-trough"
          trend="down"
          icon={<AlertCircle size={18}/>}
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <StatCard 
          label="Total Trades" 
          value={state.trades.length} 
          subValue="Challenge Progress"
          icon={<DollarSign size={18}/>}
        />
        <StatCard 
          label="Discipline Score" 
          value={`${ruleAdherence.toFixed(0)}%`} 
          subValue="Rule Adherence"
          trend={ruleAdherence > 80 ? 'up' : 'down'}
          icon={<ShieldCheck size={18}/>}
        />
        <StatCard 
          label="Loss Streak" 
          value={streak} 
          subValue="Consecutive Losses"
          trend={streak > 3 ? 'down' : 'neutral'}
          icon={<AlertCircle size={18}/>}
        />
      </div>
    </div>
  );
};

export default Dashboard;
