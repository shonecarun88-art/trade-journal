
import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Trade, JournalState } from '../types';
import { Brain, Sparkles, Loader2, X } from 'lucide-react';

interface AICoachModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: JournalState;
}

const AICoachModal: React.FC<AICoachModalProps> = ({ isOpen, onClose, state }) => {
  const [insight, setInsight] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const generateFeedback = async () => {
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const recentTrades = state.trades.slice(0, 10).map(t => ({
        pair: t.pair,
        result: t.result,
        pnl: t.pnl,
        emotion: t.emotion,
        followedRules: t.followedRules,
        notes: t.notes
      }));

      const stats = {
        totalTrades: state.trades.length,
        balance: state.currentBalance,
        winRate: (state.trades.filter(t => t.result === 'Win').length / state.trades.length) * 100,
        discipline: (state.trades.filter(t => t.followedRules).length / state.trades.length) * 100
      };

      const prompt = `
        Analyze this trader's performance and psychology. 
        Context: $100 to $500 challenge.
        Stats: ${JSON.stringify(stats)}
        Recent Trades: ${JSON.stringify(recentTrades)}
        
        Provide a concise "Coach's Report" (max 200 words). 
        Focus on:
        1. One specific discipline strength or weakness.
        2. Psychological patterns based on the "emotion" and "followedRules" data.
        3. A sharp, actionable tip for the next trade.
        Be direct, professional, and slightly tough like a prop firm manager.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });

      setInsight(response.text || "No feedback generated.");
    } catch (error) {
      console.error(error);
      setInsight("Error connecting to the coaching engine. Check your API connection.");
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden">
        <div className="p-6 border-b border-zinc-800 flex justify-between items-center bg-gradient-to-r from-emerald-600/10 to-transparent">
          <div className="flex items-center space-x-2">
            <Brain className="text-emerald-500" size={24} />
            <h2 className="text-xl font-bold">AI Trading Coach</h2>
          </div>
          <button onClick={onClose} className="text-zinc-500 hover:text-white transition-colors">
            <X size={24} />
          </button>
        </div>
        
        <div className="p-8">
          {!insight && !loading ? (
            <div className="text-center space-y-6">
              <div className="bg-zinc-800/50 p-6 rounded-2xl border border-zinc-700">
                <p className="text-zinc-300 mb-4">The AI Coach analyzes your last 10 trades, your emotional data, and rule adherence to give you a psychological edge.</p>
                <button 
                  onClick={generateFeedback}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-4 rounded-xl flex items-center justify-center space-x-2 transition-all shadow-lg"
                >
                  <Sparkles size={20} />
                  <span>Analyze My Performance</span>
                </button>
              </div>
            </div>
          ) : loading ? (
            <div className="flex flex-col items-center justify-center py-12 space-y-4">
              <Loader2 className="animate-spin text-emerald-500" size={48} />
              <p className="text-zinc-400 font-medium animate-pulse">Reading the tape & analyzing your psychology...</p>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="prose prose-invert max-w-none">
                <div className="bg-zinc-950 p-6 rounded-xl border border-zinc-800 mono text-sm leading-relaxed text-emerald-50/90 whitespace-pre-wrap">
                  {insight}
                </div>
              </div>
              <button 
                onClick={() => setInsight(null)}
                className="w-full border border-zinc-700 hover:bg-zinc-800 py-3 rounded-lg text-sm text-zinc-400 transition-colors"
              >
                Reset Analysis
              </button>
            </div>
          )}
        </div>
        
        <div className="p-4 bg-zinc-950/50 border-t border-zinc-800 flex justify-center">
          <p className="text-[10px] text-zinc-600 uppercase tracking-widest font-bold">Powered by Gemini Reasoning Engine</p>
        </div>
      </div>
    </div>
  );
};

export default AICoachModal;
