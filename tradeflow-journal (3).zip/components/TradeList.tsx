
import React from 'react';
import { Trade } from '../types';
import { Trash2, ExternalLink } from 'lucide-react';

interface TradeListProps {
  trades: Trade[];
  onDelete: (id: string) => void;
}

const TradeList: React.FC<TradeListProps> = ({ trades, onDelete }) => {
  const sortedTrades = [...trades].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-zinc-800 text-zinc-400 text-xs uppercase tracking-wider">
              <th className="p-4 font-semibold">Date</th>
              <th className="p-4 font-semibold">Pair</th>
              <th className="p-4 font-semibold">Session</th>
              <th className="p-4 font-semibold">Result</th>
              <th className="p-4 font-semibold">RR</th>
              <th className="p-4 font-semibold">PnL</th>
              <th className="p-4 font-semibold">Rules</th>
              <th className="p-4 font-semibold">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-800">
            {sortedTrades.map((trade) => (
              <tr key={trade.id} className="hover:bg-zinc-800/50 transition-colors">
                <td className="p-4 text-sm mono">{trade.date}</td>
                <td className="p-4">
                  <span className="font-bold">{trade.pair}</span>
                  <div className="text-xs text-zinc-500">{trade.setup}</div>
                </td>
                <td className="p-4 text-sm">{trade.session}</td>
                <td className="p-4">
                  <span className={`px-2 py-1 rounded text-xs font-bold ${
                    trade.result === 'Win' ? 'bg-emerald-500/10 text-emerald-500' :
                    trade.result === 'Loss' ? 'bg-rose-500/10 text-rose-500' :
                    'bg-zinc-700/10 text-zinc-400'
                  }`}>
                    {trade.result}
                  </span>
                </td>
                <td className="p-4 text-sm mono">1:{trade.rrRatio}</td>
                <td className={`p-4 text-sm font-bold mono ${trade.pnl >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                  {trade.pnl >= 0 ? '+' : ''}${trade.pnl.toFixed(2)}
                </td>
                <td className="p-4">
                  {trade.followedRules ? (
                    <span className="text-emerald-500">✓</span>
                  ) : (
                    <span className="text-rose-500">✗</span>
                  )}
                </td>
                <td className="p-4">
                  <button 
                    onClick={() => onDelete(trade.id)}
                    className="text-zinc-500 hover:text-rose-500 transition-colors"
                  >
                    <Trash2 size={16} />
                  </button>
                </td>
              </tr>
            ))}
            {sortedTrades.length === 0 && (
              <tr>
                <td colSpan={8} className="p-12 text-center text-zinc-500 italic">No trades recorded yet.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TradeList;
