
import React, { useState } from 'react';
import { TRADING_PAIRS, SESSIONS, EMOTIONS, RESULTS } from '../constants';
import { Trade, Session, Emotion, Result } from '../types';

interface TradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (trade: Trade) => void;
}

const TradeModal: React.FC<TradeModalProps> = ({ isOpen, onClose, onSave }) => {
  const [formData, setFormData] = useState<Partial<Trade>>({
    date: new Date().toISOString().split('T')[0],
    pair: 'EURUSD',
    session: 'London',
    setup: '',
    riskAmount: 1,
    stopLoss: '',
    takeProfit: '',
    result: 'Loss',
    rrRatio: 1,
    pnl: -1,
    emotion: 'Calm',
    followedRules: true,
    notes: '',
  });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trade: Trade = {
      ...formData as Trade,
      id: crypto.randomUUID(),
    };
    onSave(trade);
    onClose();
  };

  const handleResultChange = (res: Result) => {
    let pnl = 0;
    if (res === 'Win') pnl = (formData.riskAmount || 0) * (formData.rrRatio || 0);
    if (res === 'Loss') pnl = -(formData.riskAmount || 0);
    if (res === 'BE') pnl = 0;
    setFormData({ ...formData, result: res, pnl });
  };

  const handleRRChange = (rr: number) => {
    let pnl = formData.pnl || 0;
    if (formData.result === 'Win') pnl = (formData.riskAmount || 0) * rr;
    setFormData({ ...formData, rrRatio: rr, pnl });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="p-6 border-b border-zinc-800 flex justify-between items-center">
          <h2 className="text-xl font-bold">New Trade Journal</h2>
          <button onClick={onClose} className="text-zinc-400 hover:text-white">&times;</button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-zinc-400 uppercase mb-1">Date</label>
              <input 
                type="date" 
                className="w-full bg-zinc-800 border border-zinc-700 rounded-lg p-2.5 outline-none focus:border-emerald-500"
                value={formData.date}
                onChange={e => setFormData({...formData, date: e.target.value})}
                required
              />
            </div>
            <div>
              <label className="block text-xs text-zinc-400 uppercase mb-1">Pair</label>
              <select 
                className="w-full bg-zinc-800 border border-zinc-700 rounded-lg p-2.5 outline-none focus:border-emerald-500"
                value={formData.pair}
                onChange={e => setFormData({...formData, pair: e.target.value})}
              >
                {TRADING_PAIRS.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs text-zinc-400 uppercase mb-1">Session</label>
              <select 
                className="w-full bg-zinc-800 border border-zinc-700 rounded-lg p-2.5 outline-none focus:border-emerald-500"
                value={formData.session}
                onChange={e => setFormData({...formData, session: e.target.value as Session})}
              >
                {SESSIONS.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs text-zinc-400 uppercase mb-1">Setup Type</label>
              <input 
                type="text" 
                placeholder="e.g. MSS + FVG"
                className="w-full bg-zinc-800 border border-zinc-700 rounded-lg p-2.5 outline-none focus:border-emerald-500"
                value={formData.setup}
                onChange={e => setFormData({...formData, setup: e.target.value})}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs text-zinc-400 uppercase mb-1">Risk ($)</label>
              <input 
                type="number" step="0.1"
                className="w-full bg-zinc-800 border border-zinc-700 rounded-lg p-2.5 outline-none focus:border-emerald-500"
                value={formData.riskAmount}
                onChange={e => {
                  const risk = parseFloat(e.target.value);
                  setFormData({...formData, riskAmount: risk, pnl: formData.result === 'Loss' ? -risk : (formData.result === 'Win' ? risk * (formData.rrRatio || 0) : 0)});
                }}
              />
            </div>
            <div>
              <label className="block text-xs text-zinc-400 uppercase mb-1">Target RR</label>
              <input 
                type="number" step="0.1"
                className="w-full bg-zinc-800 border border-zinc-700 rounded-lg p-2.5 outline-none focus:border-emerald-500"
                value={formData.rrRatio}
                onChange={e => handleRRChange(parseFloat(e.target.value))}
              />
            </div>
             <div>
              <label className="block text-xs text-zinc-400 uppercase mb-1">Result</label>
              <select 
                className="w-full bg-zinc-800 border border-zinc-700 rounded-lg p-2.5 outline-none focus:border-emerald-500"
                value={formData.result}
                onChange={e => handleResultChange(e.target.value as Result)}
              >
                {RESULTS.map(r => <option key={r} value={r}>{r}</option>)}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-zinc-400 uppercase mb-1">Emotional State</label>
              <select 
                className="w-full bg-zinc-800 border border-zinc-700 rounded-lg p-2.5 outline-none focus:border-emerald-500"
                value={formData.emotion}
                onChange={e => setFormData({...formData, emotion: e.target.value as Emotion})}
              >
                {EMOTIONS.map(em => <option key={em} value={em}>{em}</option>)}
              </select>
            </div>
            <div className="flex items-center space-x-3 pt-6">
              <input 
                type="checkbox" 
                id="rules"
                className="w-5 h-5 accent-emerald-500 bg-zinc-800 border-zinc-700"
                checked={formData.followedRules}
                onChange={e => setFormData({...formData, followedRules: e.target.checked})}
              />
              <label htmlFor="rules" className="text-sm font-medium">I followed all my rules</label>
            </div>
          </div>

          <div>
            <label className="block text-xs text-zinc-400 uppercase mb-1">Reflection / Notes</label>
            <textarea 
              className="w-full bg-zinc-800 border border-zinc-700 rounded-lg p-2.5 outline-none focus:border-emerald-500 min-h-[100px]"
              placeholder="Why did I take this trade? How did I feel when it went into drawdown?"
              value={formData.notes}
              onChange={e => setFormData({...formData, notes: e.target.value})}
            />
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button 
              type="button" 
              onClick={onClose}
              className="px-6 py-2.5 rounded-lg border border-zinc-700 hover:bg-zinc-800 transition-colors"
            >
              Cancel
            </button>
            <button 
              type="submit"
              className="px-6 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 font-bold transition-colors"
            >
              Log Trade
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default TradeModal;
