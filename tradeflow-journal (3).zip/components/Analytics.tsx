
import React from 'react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Cell, PieChart, Pie
} from 'recharts';
import { Trade, JournalState } from '../types';

interface AnalyticsProps {
  state: JournalState;
}

const Analytics: React.FC<AnalyticsProps> = ({ state }) => {
  if (state.trades.length === 0) {
    return (
      <div className="bg-zinc-900 border border-zinc-800 p-12 rounded-xl text-center">
        <p className="text-zinc-500">Not enough data for analytics. Start trading!</p>
      </div>
    );
  }

  // Equity Curve Data
  const equityData = state.trades
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .reduce((acc: any[], trade, idx) => {
      const prevBalance = idx === 0 ? state.initialBalance : acc[idx - 1].balance;
      acc.push({
        name: idx + 1,
        balance: parseFloat((prevBalance + trade.pnl).toFixed(2))
      });
      return acc;
    }, []);

  // Pair Performance
  const pairStats = state.trades.reduce((acc: any, t) => {
    if (!acc[t.pair]) acc[t.pair] = { name: t.pair, wins: 0, total: 0 };
    acc[t.pair].total += 1;
    if (t.result === 'Win') acc[t.pair].wins += 1;
    return acc;
  }, {});
  const pairChartData = Object.values(pairStats).map((p: any) => ({
    name: p.name,
    winRate: (p.wins / p.total) * 100
  }));

  // Session Performance
  const sessionStats = state.trades.reduce((acc: any, t) => {
    if (!acc[t.session]) acc[t.session] = { name: t.session, wins: 0, total: 0 };
    acc[t.session].total += 1;
    if (t.result === 'Win') acc[t.session].wins += 1;
    return acc;
  }, {});
  const sessionChartData = Object.values(sessionStats).map((s: any) => ({
    name: s.name,
    winRate: (s.wins / s.total) * 100
  }));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Equity Curve */}
      <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-xl lg:col-span-2">
        <h3 className="text-lg font-bold mb-6">Equity Curve ($100 to $500 Challenge)</h3>
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={equityData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
              <XAxis dataKey="name" stroke="#71717a" />
              <YAxis stroke="#71717a" domain={['auto', 'auto']} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#18181b', border: '1px solid #3f3f46', borderRadius: '8px' }}
                itemStyle={{ color: '#10b981' }}
              />
              <Line type="monotone" dataKey="balance" stroke="#10b981" strokeWidth={3} dot={{ fill: '#10b981' }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Pair Performance */}
      <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-xl">
        <h3 className="text-lg font-bold mb-6">Win Rate by Pair (%)</h3>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={pairChartData}>
              <XAxis dataKey="name" stroke="#71717a" />
              <YAxis stroke="#71717a" />
              <Tooltip 
                contentStyle={{ backgroundColor: '#18181b', border: '1px solid #3f3f46', borderRadius: '8px' }}
              />
              <Bar dataKey="winRate" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Session Performance */}
      <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-xl">
        <h3 className="text-lg font-bold mb-6">Win Rate by Session (%)</h3>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={sessionChartData}>
              <XAxis dataKey="name" stroke="#71717a" />
              <YAxis stroke="#71717a" />
              <Tooltip 
                contentStyle={{ backgroundColor: '#18181b', border: '1px solid #3f3f46', borderRadius: '8px' }}
              />
              <Bar dataKey="winRate" fill="#a855f7" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Analytics;
