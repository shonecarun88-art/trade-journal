
import React from 'react';

interface StatCardProps {
  label: string;
  value: string | number;
  subValue?: string;
  trend?: 'up' | 'down' | 'neutral';
  icon?: React.ReactNode;
}

const StatCard: React.FC<StatCardProps> = ({ label, value, subValue, trend, icon }) => {
  return (
    <div className="bg-zinc-900 border border-zinc-800 p-5 rounded-xl flex flex-col justify-between">
      <div className="flex items-center justify-between mb-2">
        <span className="text-zinc-400 text-sm font-medium uppercase tracking-wider">{label}</span>
        {icon && <div className="text-zinc-500">{icon}</div>}
      </div>
      <div>
        <div className="text-2xl font-bold mono">
          {value}
        </div>
        {subValue && (
          <div className={`text-xs mt-1 ${
            trend === 'up' ? 'text-emerald-500' : 
            trend === 'down' ? 'text-rose-500' : 'text-zinc-500'
          }`}>
            {subValue}
          </div>
        )}
      </div>
    </div>
  );
};

export default StatCard;
