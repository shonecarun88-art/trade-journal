
import React from 'react';

export const TRADING_PAIRS = [
  'EURUSD', 
  'GBPUSD', 
  'USDJPY', 
  'XAUUSD', 
  'BTCUSD', 
  'ETHUSD', 
  'AUDUSD', 
  'USDCAD',
  'EURJPY',
  'NZDUSD',
  'AUDJPY'
];

export const SESSIONS: string[] = ['London', 'NY', 'Asia'];

export const EMOTIONS: string[] = ['Calm', 'Stressed', 'Confident', 'Revenge'];

export const RESULTS: string[] = ['Win', 'Loss', 'BE'];

export const INITIAL_STATE = {
  initialBalance: 100,
  currentBalance: 100,
  trades: [],
  dailyLossLimit: 2,
};
