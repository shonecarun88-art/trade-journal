
import React, { useState, useEffect, useRef } from 'react';
import { View, Trade, JournalState } from './types';
import { INITIAL_STATE } from './constants';
import Dashboard from './components/Dashboard';
import TradeList from './components/TradeList';
import Analytics from './components/Analytics';
import TradeModal from './components/TradeModal';
import AICoachModal from './components/AICoachModal';
import { 
  LayoutDashboard, 
  History, 
  PieChart, 
  Settings, 
  Plus, 
  Terminal, 
  Brain,
  Download,
  Upload,
  ShieldCheck
} from 'lucide-react';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<View>(View.Dashboard);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCoachOpen, setIsCoachOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [state, setState] = useState<JournalState>(() => {
    const saved = localStorage.getItem('tradeflow_v1');
    return saved ? JSON.parse(saved) : INITIAL_STATE;
  });

  useEffect(() => {
    localStorage.setItem('tradeflow_v1', JSON.stringify(state));
  }, [state]);

  const handleAddTrade = (newTrade: Trade) => {
    setState(prev => ({
      ...prev,
      trades: [newTrade, ...prev.trades],
      currentBalance: prev.currentBalance + newTrade.pnl
    }));
  };

  const handleDeleteTrade = (id: string) => {
    const tradeToDelete = state.trades.find(t => t.id === id);
    if (tradeToDelete) {
      setState(prev => ({
        ...prev,
        trades: prev.trades.filter(t => t.id !== id),
        currentBalance: prev.currentBalance - tradeToDelete.pnl
      }));
    }
  };

  const handleUpdateBalance = (newBalance: number) => {
    setState(prev => ({ ...prev, currentBalance: newBalance }));
  };

  const exportData = () => {
    const dataStr = JSON.stringify(state, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const exportFileDefaultName = `tradeflow-backup-${new Date().toISOString().split('T')[0]}.json`;
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const importData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const json = JSON.parse(e.target?.result as string);
        if (json.trades && typeof json.currentBalance === 'number') {
          if (confirm('Import data? This will overwrite your current journal.')) {
            setState(json);
          }
        }
      } catch (err) {
        alert('Invalid backup file.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="min-h-screen bg-black flex flex-col md:flex-row">
      {/* Sidebar Navigation */}
      <aside className="w-full md:w-64 bg-zinc-950 border-r border-zinc-900 md:flex flex-col shrink-0">
        <div className="p-6 flex items-center space-x-3">
          <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center">
            <Terminal className="text-white" />
          </div>
          <div>
            <h1 className="font-bold text-lg leading-tight">TradeFlow</h1>
            <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Journaling Engine</p>
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-1">
          {[
            { id: View.Dashboard, icon: LayoutDashboard, label: 'Dashboard' },
            { id: View.Trades, icon: History, label: 'Trade History' },
            { id: View.Analytics, icon: PieChart, label: 'Performance' },
            { id: View.Settings, icon: Settings, label: 'Settings' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id)}
              className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg transition-all ${
                activeView === item.id 
                  ? 'bg-emerald-600/10 text-emerald-500 font-medium' 
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
              }`}
            >
              <item.icon size={20} />
              <span>{item.label}</span>
            </button>
          ))}
          <div className="pt-4 border-t border-zinc-900 mt-4 mx-2">
            <button
              onClick={() => setIsCoachOpen(true)}
              className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-emerald-400 hover:bg-emerald-500/10 transition-all border border-emerald-900/50"
            >
              <Brain size={20} />
              <span>AI Coach</span>
            </button>
          </div>
        </nav>

        <div className="p-4 border-t border-zinc-900">
          <button 
            onClick={() => setIsModalOpen(true)}
            className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 rounded-xl flex items-center justify-center space-x-2 transition-all shadow-lg shadow-emerald-900/20"
          >
            <Plus size={20} />
            <span>New Entry</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto p-4 md:p-8">
        <div className="max-w-6xl mx-auto pb-24 md:pb-8">
          <header className="mb-8 flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-bold capitalize">
                {activeView === View.Dashboard ? 'Executive Overview' : 
                 activeView === View.Trades ? 'Trade Ledger' : 
                 activeView === View.Analytics ? 'Advanced Analytics' : 'Configuration'}
              </h2>
              <p className="text-zinc-500 text-sm">Tracking the $100 to $500 account challenge.</p>
            </div>
            <div className="hidden md:block">
              <div className="px-4 py-2 bg-zinc-900 border border-zinc-800 rounded-full flex items-center space-x-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="text-xs font-medium text-zinc-400 uppercase tracking-tighter">System Live</span>
              </div>
            </div>
          </header>

          <div className="animate-in fade-in slide-in-from-bottom-2 duration-300">
            {activeView === View.Dashboard && (
              <Dashboard state={state} onUpdateBalance={handleUpdateBalance} />
            )}
            {activeView === View.Trades && (
              <TradeList trades={state.trades} onDelete={handleDeleteTrade} />
            )}
            {activeView === View.Analytics && (
              <Analytics state={state} />
            )}
            {activeView === View.Settings && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-zinc-900 border border-zinc-800 p-8 rounded-xl">
                  <h3 className="text-xl font-bold mb-6 flex items-center space-x-2">
                    <Settings className="text-zinc-400" size={20} />
                    <span>Risk Parameters</span>
                  </h3>
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium mb-2 text-zinc-400">Daily Loss Limit ($)</label>
                      <input 
                        type="number" 
                        className="w-full bg-zinc-800 border border-zinc-700 rounded-lg p-3 outline-none focus:border-emerald-500 mono text-emerald-500 font-bold"
                        value={state.dailyLossLimit}
                        onChange={e => setState({...state, dailyLossLimit: parseFloat(e.target.value)})}
                      />
                      <p className="text-[11px] text-zinc-500 mt-2 uppercase">Warning triggered at reach.</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2 text-zinc-400">Initial Deposit ($)</label>
                      <input 
                        type="number" 
                        className="w-full bg-zinc-800 border border-zinc-700 rounded-lg p-3 outline-none focus:border-emerald-500 mono"
                        value={state.initialBalance}
                        onChange={e => setState({...state, initialBalance: parseFloat(e.target.value)})}
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-zinc-900 border border-zinc-800 p-8 rounded-xl flex flex-col justify-between">
                  <div>
                    <h3 className="text-xl font-bold mb-6 flex items-center space-x-2">
                      <ShieldCheck className="text-emerald-500" size={20} />
                      <span>Data Portability</span>
                    </h3>
                    <p className="text-sm text-zinc-400 mb-6 leading-relaxed">
                      Move your data between your laptop and mobile device by exporting the journal state to a JSON file.
                    </p>
                  </div>
                  <div className="space-y-3">
                    <button 
                      onClick={exportData}
                      className="w-full bg-zinc-800 hover:bg-zinc-700 text-white font-medium py-3 rounded-xl flex items-center justify-center space-x-2 transition-all"
                    >
                      <Download size={18} />
                      <span>Download Backup (.json)</span>
                    </button>
                    <button 
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full border border-zinc-700 hover:bg-zinc-800 text-zinc-300 font-medium py-3 rounded-xl flex items-center justify-center space-x-2 transition-all"
                    >
                      <Upload size={18} />
                      <span>Restore from Backup</span>
                    </button>
                    <input 
                      type="file" 
                      ref={fileInputRef} 
                      className="hidden" 
                      accept=".json" 
                      onChange={importData} 
                    />
                    <div className="pt-6 border-t border-zinc-800 mt-6">
                      <button 
                        onClick={() => {
                          if(confirm('Erase all journal data? This cannot be undone.')) {
                            setState(INITIAL_STATE);
                          }
                        }}
                        className="text-rose-500 text-xs hover:underline uppercase font-bold tracking-widest"
                      >
                        Factory Reset
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Trade Entry Modal */}
      <TradeModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onSave={handleAddTrade} 
      />

      {/* AI Coach Modal */}
      <AICoachModal 
        isOpen={isCoachOpen}
        onClose={() => setIsCoachOpen(false)}
        state={state}
      />

      {/* Mobile Bottom Bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-zinc-950 border-t border-zinc-900 flex justify-around p-3 z-40 backdrop-blur-lg bg-black/80">
        {[
          { id: View.Dashboard, icon: LayoutDashboard },
          { id: View.Trades, icon: History },
          { id: View.Analytics, icon: PieChart },
          { id: View.Settings, icon: Settings },
        ].map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveView(item.id)}
            className={`p-2 rounded-lg ${activeView === item.id ? 'text-emerald-500 bg-emerald-500/10' : 'text-zinc-500'}`}
          >
            <item.icon size={24} />
          </button>
        ))}
      </div>

      {/* Mobile FAB */}
      <div className="md:hidden fixed bottom-20 right-6 z-50">
        <button 
          onClick={() => setIsModalOpen(true)}
          className="w-16 h-16 bg-emerald-600 rounded-full shadow-2xl flex items-center justify-center text-white ring-4 ring-black"
        >
          <Plus size={32} />
        </button>
      </div>
    </div>
  );
};

export default App;
